package br.com.escalatop.escala_top

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
